$(function () {

    $('#contact-form').validator();
});
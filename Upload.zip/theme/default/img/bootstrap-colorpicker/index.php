<?php
/*
 * @author Balaji
 * @name: Flag Counter - PHP Script
 * @copyright � 2015 ProThemes.Biz
 *
 */
 
// Disable Errors
error_reporting(1);

?>